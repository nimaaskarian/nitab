window.open("/index.html");
window.close();
